public class Figura {
    
}
