public class Losango extends Quadrilatero {
    
}
