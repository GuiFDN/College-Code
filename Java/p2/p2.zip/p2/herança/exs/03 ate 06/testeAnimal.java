public class testeAnimal {
    public static void main(String[] args) {
        Cachorro Hiro = new Cachorro("Hiro");
        Gato Fuba = new Gato("Fuba");
        Gato Carlos = new Gato("Carlos");
        Cachorro doggo = new Cachorro("doggo");
    }
}