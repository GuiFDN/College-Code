public class Gato extends Mamifero {
    public Gato (String nome) {
        super(4, nome);
    }
}
