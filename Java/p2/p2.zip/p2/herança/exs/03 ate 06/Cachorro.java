public class Cachorro extends Mamifero{
    public Cachorro (String nome) {
        super(4, nome);
    }
}
