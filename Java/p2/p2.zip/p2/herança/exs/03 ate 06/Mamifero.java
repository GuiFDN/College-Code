public class Mamifero extends Animal {
    public Mamifero (int patas, String nome) {
        super(patas, nome);
    }
}
